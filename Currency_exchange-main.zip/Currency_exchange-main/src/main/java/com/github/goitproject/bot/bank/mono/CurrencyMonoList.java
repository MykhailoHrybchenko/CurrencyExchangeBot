package com.github.goitproject.bot.bank.mono;

import java.util.ArrayList;

public class CurrencyMonoList extends ArrayList<MonoBank> {

}
