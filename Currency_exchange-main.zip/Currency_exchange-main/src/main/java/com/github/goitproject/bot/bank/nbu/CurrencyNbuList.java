package com.github.goitproject.bot.bank.nbu;

import java.util.ArrayList;

public class CurrencyNbuList extends ArrayList<NbuBank> {
}
