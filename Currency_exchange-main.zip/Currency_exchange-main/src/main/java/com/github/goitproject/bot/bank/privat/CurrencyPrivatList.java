package com.github.goitproject.bot.bank.privat;

import java.util.ArrayList;

public class CurrencyPrivatList extends ArrayList<PrivatBank> {
}
